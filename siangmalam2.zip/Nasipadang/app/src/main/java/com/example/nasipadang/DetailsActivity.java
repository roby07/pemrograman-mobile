package com.example.nasipadang;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsActivity extends AppCompatActivity{
    TextView nama, harga;
    String playername,playerharga;
    EditText edtharga, edtjumlahbel,edtuangbay;
    Button btnproses;
    TextView txtjumlahbel;
    TextView txtuangbay;
    TextView txttotalbelanja;
    TextView txtuangkembali;
    TextView txtketerangan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        nama=findViewById(R.id.nama);
        harga=findViewById(R.id.harga);
        edtharga=(EditText) findViewById(R.id.harga1);
        edtjumlahbel = (EditText) findViewById(R.id.jumlahbeli);
        edtuangbay = (EditText) findViewById(R.id.uangbayar);
        btnproses = (Button) findViewById(R.id.tombol1);
        txtjumlahbel = (TextView) findViewById(R.id.jumlahbeli);
        txtuangbay = (TextView) findViewById(R.id.uangbayar);
        txttotalbelanja = (TextView) findViewById(R.id.totalbelanja);
        txtuangkembali = (TextView) findViewById(R.id.uangkembali);
        txtketerangan = (TextView) findViewById(R.id.keterangan);

        playername=getIntent().getStringExtra("name");
        playerharga=getIntent().getStringExtra("harga");

        nama.setText(playername);
        harga.setText(playerharga);

        btnproses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String jumlahbeli = edtjumlahbel.getText().toString().trim();
                String harga = edtharga.getText().toString().trim();
                String uangbayar = edtuangbay.getText().toString().trim();

                double jb = Double.parseDouble(jumlahbeli);
                double h = Double.parseDouble(harga);
                double ub = Double.parseDouble(uangbayar);
                double total = (jb * h);
                txttotalbelanja.setText("Total Belanja : " + total);


                double uangkembalian = (ub - total);

                if (ub < total){
                    txtketerangan.setText("Keterangan : Uang Bayarnya Kurang");
                    txtuangkembali.setText("Uang Kembali : -" + (-uangkembalian) );
                }else{
                    txtketerangan.setText("Keterangan : Tunggu Kembalian");
                    txtuangkembali.setText("Uang Kembali : " + uangkembalian);
                }

            }
        });
    }


}
