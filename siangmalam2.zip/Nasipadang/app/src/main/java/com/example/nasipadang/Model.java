package com.example.nasipadang;

public class Model {
    int image;
    String player_name, player_harga;
    public Model(int image, String player_name, String player_harga) {
        this.image = image;
        this.player_name = player_name;
        this.player_harga = player_harga;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getPlayer_name() {
        return player_name;
    }

    public void setPlayer_name(String player_name) {
        this.player_name = player_name;
    }

    public String getPlayer_harga() {
        return player_harga;
    }

    public void setPlayer_harga(String player_harga) {
        this.player_harga = player_harga;
    }
}
