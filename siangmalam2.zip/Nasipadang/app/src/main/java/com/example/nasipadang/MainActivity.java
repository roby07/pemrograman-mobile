package com.example.nasipadang;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Model> main_list;
    RecyclerView.Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main_list=new ArrayList<>();
        recyclerView=findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        main_list.add(new Model(R.drawable.masakan1,
                "Nasi Dendeng",
                "Rp. 20000"));
        main_list.add(new Model(R.drawable.kikil,
                "Nasi Ikan",
                "Rp. 22000"));

        main_list.add(new Model(R.drawable.perkedel,
                "Nasi Perkedel",
                "Rp. 15000"));

        main_list.add(new Model(R.drawable.rendang,
                "Nasi Rendang",
                "Rp. 20000"));

        main_list.add(new Model(R.drawable.ayam,
                "Nasi Ayam Gulai",
                "Rp. 20000"));

        main_list.add(new Model(R.drawable.tempe,
                "Nasi Tempe Kare",
                "Rp. 10000"));

        adapter=new CustomAdapter(getApplicationContext(),main_list);
        recyclerView.setAdapter(adapter);
    }
}
